var searchData=
[
  ['battarypolarity',['BattaryPolarity',['../class_r_t_1_1_parsing_libs_1_1_models_1_1_automoto_additional_info.html#a49dbc11eefabf4e445b07a6a413a8db5',1,'RT::ParsingLibs::Models::AutomotoAdditionalInfo']]],
  ['battaryvoltage',['BattaryVoltage',['../class_r_t_1_1_parsing_libs_1_1_models_1_1_automoto_additional_info.html#a203517e7d58699bc5a63d899c3eacbe4',1,'RT::ParsingLibs::Models::AutomotoAdditionalInfo']]],
  ['bodycolor',['BodyColor',['../class_r_t_1_1_parsing_libs_1_1_models_1_1_automoto_additional_info.html#a6c50c18d9c366a0692fa520b922df0a7',1,'RT::ParsingLibs::Models::AutomotoAdditionalInfo']]],
  ['bodysize',['BodySize',['../class_r_t_1_1_parsing_libs_1_1_models_1_1_automoto_additional_info.html#a4af1d9c1626189c5704ecedffc9a4d32',1,'RT::ParsingLibs::Models::AutomotoAdditionalInfo']]],
  ['bodytype',['BodyType',['../class_r_t_1_1_parsing_libs_1_1_models_1_1_automoto_additional_info.html#aea0f5f014f2d4efab5d2beb9e062062c',1,'RT::ParsingLibs::Models::AutomotoAdditionalInfo']]],
  ['brand',['Brand',['../class_r_t_1_1_parsing_libs_1_1_models_1_1_automoto_additional_info.html#ae7f8603916fad1afa37cae1f7a3349a4',1,'RT::ParsingLibs::Models::AutomotoAdditionalInfo']]]
];
