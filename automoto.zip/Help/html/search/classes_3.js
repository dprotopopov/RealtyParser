var searchData=
[
  ['realtyadditionalinfo',['RealtyAdditionalInfo',['../class_r_t_1_1_parsing_libs_1_1_models_1_1_realty_additional_info.html',1,'RT::ParsingLibs::Models']]]
];
