var searchData=
[
  ['bind',['Bind',['../class_r_t_1_1_parsing_libs_1_1_models_1_1_bind.html#a1f267ab735462ac9086c6f1eec2ebffe',1,'RT.ParsingLibs.Models.Bind.Bind()'],['../class_r_t_1_1_parsing_libs_1_1_models_1_1_bind.html#a982063bf083039d7f1d9704dcd5c86ac',1,'RT.ParsingLibs.Models.Bind.Bind(int rubricId, int actionId, int regionId)']]]
];
