﻿namespace RT.ParsingLibs.Models
{
    /// <summary>
    /// <see cref="RT.ParsingLibs.Models"/> пространство содержит базовые модели для парсеров
    /// </summary>

    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
