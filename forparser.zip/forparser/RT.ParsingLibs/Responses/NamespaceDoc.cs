﻿namespace RT.ParsingLibs.Responses
{
    /// <summary>
    /// <see cref="RT.ParsingLibs.Responses"/> пространство содержит ответы от парсеров
    /// </summary>

    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}