﻿namespace RT.ParsingLibs
{
    /// <summary>
    /// <see cref="RT.ParsingLibs"/> пространство содержит базовые классы всех парсеров
    /// </summary>

    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
