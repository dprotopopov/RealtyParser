﻿namespace RT.ParsingLibs
{
    /// <summary>
    /// Константы
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// Количество объявлений (CountAD).
        /// </summary>
        public const int CountPublications = 30;
    }
}
