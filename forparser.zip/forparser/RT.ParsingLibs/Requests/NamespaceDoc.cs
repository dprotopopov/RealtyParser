﻿namespace RT.ParsingLibs.Requests
{
    /// <summary>
    /// <see cref="RT.ParsingLibs.Requests"/> пространство содержит запросы к парсерам
    /// </summary>

    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
