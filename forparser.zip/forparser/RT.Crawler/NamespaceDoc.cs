﻿namespace RT.Crawler
{
    /// <summary>
    /// <see cref="RT.Crawler"/> пространство содержит классы для загрузки контента с сайтов.
    /// </summary>

    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
